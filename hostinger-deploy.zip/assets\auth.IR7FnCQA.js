import{A as p}from"./auth.Bbbx5z5J.js";import"./firebase.BNzpyJs9.js";import"./jsx-runtime.D_zvdyIk.js";import"./index.CEK5zJnf.js";export{p as AuthProvider};
