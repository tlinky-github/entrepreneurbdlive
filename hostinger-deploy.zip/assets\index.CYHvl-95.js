import{g as r}from"./index.CEK5zJnf.js";import{r as o}from"./index.DorHZqxH.js";var t=o();const m=r(t);export{m as R,t as r};
